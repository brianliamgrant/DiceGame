package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Dice;
import model.Game;

/**
 * Servlet implementation class EndServlet
 */
@WebServlet(description = "Takes the request from the BetPage.jsp when the quit button is pressed", urlPatterns = { "/EndServlet" })
public class EndServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EndServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Game g = new Game();
		g.setBalance(Double.parseDouble(request.getParameter("currBalance")));
		int counter = Integer.parseInt(request.getParameter("counter"));
		double balance = g.getBalance();
		
		//define the url string of the page the result page the user should view
		String url = "/EndGame.jsp";
		
		//pass the request and response object to the results jsp
		request.setAttribute("balance", balance);
		request.setAttribute("counter", counter);
		RequestDispatcher dispatch = request.getRequestDispatcher(url);
		dispatch.forward(request, response);
	}

}
