package controller;

import java.io.IOException;
import java.text.NumberFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Dice;
import model.Game;

/**
 * Servlet implementation class ResultServlet
 */
@WebServlet(description = "Takes the request from BetPage.jsp and sends it to either the ResultPage.jsp whe the place button is pressed", 
urlPatterns = { "/ResultServlet" })
public class ResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResultServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Pass information from the request to dice and game classes accordingly
		double bet = Double.parseDouble(request.getParameter("bet"));
		String type = request.getParameter("betType");
		double currBalance = Double.parseDouble(request.getParameter("currBalance"));
		int counter = Integer.parseInt(request.getParameter("counter"));
		
		//pass user input to the Game class
		Game g = new Game(); 
		g.setBet(bet);
		g.setBetType(type);
		g.setBalance(currBalance);
		
		//set random dice value
		Dice d1 = new Dice();
		d1.setRandom();
		Dice d2 = new Dice();
		d2.setRandom();
		
		//update the balance and msg in the Game class
		double balance = g.updateBalance(currBalance, d1, d2);
		String msg = g.getMsg();
		String dice1 = d1.toString();
		String dice2 = d2.toString();
		
		//define the url string of the page the result page the user should view
		String url = "/ResultPage.jsp";
		
		//add values to the request object to pass to the destination
		request.setAttribute("betType", type);
		request.setAttribute("bets", bet);
		request.setAttribute("balance", balance);
		request.setAttribute("counter", counter);
		request.setAttribute("msg", msg);
		request.setAttribute("dice1", dice1);
		request.setAttribute("dice2", dice2);
		
		//pass the request and response object to the results jsp
		RequestDispatcher dispatch = request.getRequestDispatcher(url);
		dispatch.forward(request, response);	
	}
}
