/**
 * 
 */
package model;

import java.text.NumberFormat;

/**
 * @author brianliamgrant
 *
 */
public class Game extends Dice {
	private double balance;
	private double bet;
	private int rollCounter;
	private String betType;
	private String msg;
	
	NumberFormat nf = NumberFormat.getCurrencyInstance();
	
	/**
	 * default constructor
	 */
	public Game() {
		
	}

	/**
	 * @return the current balance in US currency format
	 */
	public double getBalance() {
		return balance;
	}

	/**
	 * @param balance the balance to set
	 */
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public double updateBalance(double balance, Dice d1, Dice d2) {
		this.msg = "";
		double sum = d1.getValue() + d2.getValue();
		if((getBetType().contains("L") && sum < 7) ||
				(getBetType().contains("H") && sum > 7)){
			this.balance = getBet() + balance;
			msg = "Congratulations! You won " + nf.format(getBet()) + ".";
		} else if((getBetType().contains("S") && sum == 7)) {
			this.balance = (getBet() * 4)+ balance;
			msg = "Congratulations! You won " + nf.format(getBet() * 4) + ".";
		} else {
			this.balance = balance - getBet();
			msg = "Tough luck. You lost " + nf.format(getBet()) + ".";
		}
		setMsg(msg);
		return this.balance;
	}
	
	/**
	 * @return the msg
	 */
	public String getMsg() {
		return msg;
	}

	/**
	 * @param msg the msg to set
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	/**
	 * @return the bet
	 */
	public double getBet() {
		return bet;
	}

	/**
	 * @param bet the bet to set
	 */
	public void setBet(double bet) {
		this.bet = bet;
	}

	/**
	 * @return the rollCounter
	 */
	public int getRollCounter() {
		return rollCounter;
	}

	/**
	 * @param rollCounter the rollCounter to set
	 */
	public void setRollCounter(int rollCounter) {
		this.rollCounter = rollCounter;
	}

	public int updateRollCounter() {
		this.rollCounter++;
		return rollCounter;
	}
	
	public int decreaseCounter() {
		rollCounter--;
		return rollCounter;
	}
	
	/**
	 * @return the betType
	 */
	public String getBetType() {
		return betType;
	}

	/**
	 * @param betType the betType to set
	 */
	public void setBetType(String betType) {
		this.betType = betType;
	}
}
