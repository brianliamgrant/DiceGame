/**
 * 
 */
package model;

import java.util.Random;

/**
 * @author brianliamgrant
 *
 */
public class Dice {

	private int value;

	/**
	 * default constructor
	 */
	public Dice() {
		this.value = 1;
	}

	/**
	 * constructor that will take the request values
	 * @param value
	 */
	public Dice(int value) {
		this.value = value;
	}

	/**
	 * @return the value
	 */
	public int getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(int value) {
		this.value = value;
	}
	
	public void setRandom() {
		Random r = new Random();
		this.value = r.nextInt(6) + 1;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		String displayDice = "<img ";
		switch(getValue()) {
		case 1:
			displayDice += "src='diceOne.jpg'/>";
			break;
		case 2:
			displayDice += "src='diceTwo.jpg'/>";
			break;
		case 3:
			displayDice += "src='diceThree.jpg'/>";
			break;
		case 4:
			displayDice += "src='diceFour.jpg'/>";
			break;
		case 5:
			displayDice += "src='diceFive.jpg'/>";
			break;
		case 6:
			displayDice += "src='diceSix.jpg'/>";
			break;
		}
		return displayDice;
	}
	
}
